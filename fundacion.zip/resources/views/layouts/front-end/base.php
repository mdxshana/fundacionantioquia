@extends('layouts.back-end.layout')

@section('style')
@endsection

@section('encabezado')
<div class="page-banner">
    <div class="container" style="opacity:0.9;">
        <div class="row">
            <div class="col-md-6">
                <h2>Services</h2>
                <p>We Are Professional</p>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumbs">
                    <li><a href="#">Home</a></li>
                    <li>Services</li>
                </ul>
            </div>
        </div>
    </div>
</div>
@endsection


@section('content')
@endsection

@section('script')
@endsection