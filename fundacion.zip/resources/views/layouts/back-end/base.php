@extends('layouts.back-end.layout')

@section('style')
@endsection

@section('cabecera')
<div class="panel box-shadow-none content-header">
    <div class="panel-body">
        <div class="col-md-12">
            <h3 class="animated fadeInLeft">Article v1</h3>
            <p class="animated fadeInDown">
                Pages <span class="fa-angle-right fa"></span> Article v1
            </p>
        </div>
    </div>
</div>
@endsection

@section('content')
@endsection

@section('script')
@endsection