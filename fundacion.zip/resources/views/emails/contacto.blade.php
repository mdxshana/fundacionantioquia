<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>



<div id="mi-imagen">

</div>

<p><strong>Nombre :</strong>{!! $nombre !!}</p>
<p><strong>Asunto :</strong>{!! $asunto !!}</p>
<p><strong>Mensaje </strong>{!! $mensaje !!}</p>


</body>
</html>