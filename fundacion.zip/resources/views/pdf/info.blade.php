<img src="images/logo.png" width="100%" height="110px">

<div class="row">
    <div class="col-xs-12">
        {!! $pdf !!}
    </div>
</div>