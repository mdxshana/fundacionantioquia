<!doctype html>
<html lang="es">

<head>

  <!-- Basic -->
  

  <!-- Define Charset -->
  <meta charset="utf-8">

  <!-- Responsive Metatag -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="keywords" content="fundación,fundaciones,rehabilitacion,adicción,teo-terapeutico,teo-terapia">
  <!-- Page Description and Author -->
  <meta name="description" content="Margo - Responsive HTML5 Template">
  <meta name="author" content="iThemesLab">
  <meta name='csrf-param' content='authenticity_token'>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <!-- Bootstrap CSS  -->
  <?php echo Html::style('front-end/asset/css/bootstrap.min.css'); ?>

  

  <!-- Font Awesome CSS -->
  <?php echo Html::style('front-end/css/font-awesome.min.css'); ?>

  

  <!-- Slicknav -->
  <?php echo Html::style('front-end/css/slicknav.css'); ?>

  

  <!-- Margo CSS Styles  -->
  <?php echo Html::style('front-end/css/style.css'); ?>

  

  <!-- Responsive CSS Styles  -->
  <?php echo Html::style('front-end/css/responsive.css'); ?>

  

  <!-- Css3 Transitions Styles  -->
  <?php echo Html::style('front-end/css/animate.css'); ?>

  

  <!-- Color CSS Styles  -->
  <?php echo Html::style('front-end/css/color.css'); ?>

  
  
  
  
  
  
  
  
  
  
  
  

  <?php echo $__env->yieldContent('style'); ?>
  <style>
    .twitter-widget ul li {
       margin-bottom: 5px;
    }
  </style>
</head>

<body>
  <!-- Container -->
  <div id="container">
    <!-- Start Header -->
    <div class="hidden-header"></div>
    <header class="clearfix">
      <!-- Start Top Bar -->
      <div class="top-bar">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <!-- Start Contact Info -->
              <ul class="contact-details">
                <li><a href="#"><i class="fa fa-map-marker"></i> Km 12 Vía Acacías</a> </li>
                <li><a href="#"><i class="fa fa-envelope-o"></i> concacto@fundacionantioquia.com</a> </li>
                <li><a href="#"><i class="fa fa-phone"></i> 310 858 9044 - 318 313 8472</a> </li>
              </ul>
              <!-- End Contact Info -->
            </div>
            <div class="col-md-6">
              <!-- Start Social Links -->
              <ul class="social-list">
                <li> <a class="facebook itl-tooltip" data-placement="bottom" title="Facebook" href="#"><i class="fa fa-facebook"></i></a> </li>
                <li> <a class="twitter itl-tooltip" data-placement="bottom" title="Twitter" href="#"><i class="fa fa-twitter"></i></a> </li>
                <li> <a class="google itl-tooltip" data-placement="bottom" title="Google Plus" href="#"><i class="fa fa-google-plus"></i></a> </li>
                <li> <a class="dribbble itl-tooltip" data-placement="bottom" title="Dribble" href="#"><i class="fa fa-dribbble"></i></a> </li>
                <li> <a class="linkdin itl-tooltip" data-placement="bottom" title="Linkedin" href="#"><i class="fa fa-linkedin"></i></a> </li>
                <li> <a class="flickr itl-tooltip" data-placement="bottom" title="Flickr" href="#"><i class="fa fa-flickr"></i></a> </li>
                <li> <a class="tumblr itl-tooltip" data-placement="bottom" title="Tumblr" href="#"><i class="fa fa-tumblr"></i></a> </li>
                <li> <a class="instgram itl-tooltip" data-placement="bottom" title="Instagram" href="#"><i class="fa fa-instagram"></i></a> </li>
                <li> <a class="vimeo itl-tooltip" data-placement="bottom" title="vimeo" href="#"><i class="fa fa-vimeo-square"></i></a> </li>
                <li> <a class="skype itl-tooltip" data-placement="bottom" title="Skype" href="#"><i class="fa fa-skype"></i></a> </li>
              </ul>
              <!-- End Social Links -->
            </div>
          </div>
        </div>
      </div>
      <!-- End Top Bar -->
      <!-- Start Header ( Logo & Naviagtion ) -->
      <?php echo $__env->make('layouts.front-end.menu-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- End Header ( Logo & Naviagtion ) -->
    </header>
    <!-- End Header -->

    <?php echo $__env->yieldContent('encabezado'); ?>

    <!-- Start Content -->
    <div id="content">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- End Content -->

    <!-- Start Footer -->
    <footer>
      <div class="container">
        <div class="row footer-widgets">

          <!-- Start Subscribe & Social Links Widget -->
          <div class="col-md-3 col-md-offset-2">
            <div class="footer-widget social-widget">
              <h4>Siguenos<span class="head-line"></span></h4>
              <ul class="social-icons">
                <li>
                  <a class="facebook" href="#"><i class="fa fa-facebook"></i></a>
                </li>
                <li>
                  <a class="twitter" href="#"><i class="fa fa-twitter"></i></a>
                </li>
                <li>
                  <a class="google" href="#"><i class="fa fa-google-plus"></i></a>
                </li>
                <li>
                  <a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a>
                </li>
                <li>
                  <a class="linkdin" href="#"><i class="fa fa-linkedin"></i></a>
                </li>
                <li>
                  <a class="flickr" href="#"><i class="fa fa-flickr"></i></a>
                </li>
                <li>
                  <a class="tumblr" href="#"><i class="fa fa-tumblr"></i></a>
                </li>
                <li>
                  <a class="instgram" href="#"><i class="fa fa-instagram"></i></a>
                </li>
                <li>
                  <a class="vimeo" href="#"><i class="fa fa-vimeo-square"></i></a>
                </li>
                <li>
                  <a class="skype" href="#"><i class="fa fa-skype"></i></a>
                </li>
              </ul>
            </div>
          </div>
          <!-- .col-md-3 -->
          <!-- End Subscribe & Social Links Widget -->


          <!-- Start Twitter Widget -->
          <div class="col-md-6 col-md-offset-1">
            <div class="footer-widget twitter-widget">
              <h4>Contactenos<span class="head-line"></span></h4>
              <ul>
                <li><i class="fa fa-globe">  </i> <strong>Dirección:</strong> Km 12 Vía Acacías, Vereda la Union, Sector Naturalia, Finca El Paraiso</li>
                <li><i class="fa fa-envelope-o"></i> <strong>Email:</strong> concacto@fundacionantioquia.com</li>
                <li><i class="fa fa-mobile"></i> <strong>Phone:</strong> 311 480 8110 - 310 858 9044 - 318 313 8472</li>
              </ul>
            </div>
          </div>
          <!-- .col-md-3 -->
          <!-- End Twitter Widget -->


          <!-- Start Flickr Widget -->
          
            
              
              
                
                  
                    
                  
                
                
                  
                    
                  
                
                
                  
                    
                  
                
                
                  
                    
                  
                
                
                  
                    
                  
                
                
                  
                    
                  
                
                
                  
                    
                  
                
                
                  
                    
                  
                
                
                  
                    
                  
                
              
            
          
          <!-- .col-md-3 -->
          <!-- End Flickr Widget -->


          <!-- Start Contact Widget -->
          
            
              
              
              
                
                
                
              
            
          
          <!-- .col-md-3 -->
          <!-- End Contact Widget -->


        </div>
        <!-- .row -->

        <!-- Start Copyright -->
        <div class="copyright-section">
          <div class="row">
            <div class="col-md-12">
              <p style="text-align: center">&copy; 2017 Ceindeted Llanos - Todos los derechos reservados</p>
            </div>
            
              
                
                
                
              
            
          </div>
        </div>
        <!-- End Copyright -->

      </div>
    </footer>
    <!-- End Footer -->

  </div>
  <!-- End Container -->

  <!-- Go To Top Link -->
  <a href="#" class="back-to-top"><i class="fa fa-angle-up"></i></a>




  <!-- Margo JS  -->
  <?php echo Html::script('front-end/js/jquery-2.1.4.min.js'); ?>

  <?php echo Html::script('front-end/js/jquery.migrate.js'); ?>

  <?php echo Html::script('front-end/js/modernizrr.js'); ?>

  <?php echo Html::script('front-end/asset/js/bootstrap.min.js'); ?>

  <?php echo Html::script('front-end/js/jquery.fitvids.js'); ?>

  <?php echo Html::script('front-end/js/owl.carousel.min.js'); ?>

  <?php echo Html::script('front-end/js/nivo-lightbox.min.js'); ?>

  <?php echo Html::script('front-end/js/jquery.isotope.min.js'); ?>

  <?php echo Html::script('front-end/js/jquery.appear.js'); ?>

  <?php echo Html::script('front-end/js/count-to.js'); ?>

  <?php echo Html::script('front-end/js/jquery.textillate.js'); ?>

  <?php echo Html::script('front-end/js/jquery.lettering.js'); ?>

  <?php echo Html::script('front-end/js/jquery.easypiechart.min.js'); ?>

  <?php echo Html::script('front-end/js/jquery.nicescroll.min.js'); ?>

  <?php echo Html::script('front-end/js/jquery.parallax.js'); ?>

  <?php echo Html::script('front-end/js/mediaelement-and-player.js'); ?>

  <?php echo Html::script('front-end/js/jquery.slicknav.js'); ?>

  <?php echo Html::script('front-end/js/script.js'); ?>

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


  
  

  

  <!-- Modal Bootstrap-->
  <div id='modalBs' class='modal fade'>
    <div class="modal-dialog">
      <div class="modal-content">
      </div>
    </div>
  </div>


  <?php echo Html::script('js/inicio.js'); ?>

<?php echo $__env->yieldContent('script'); ?>

  <script>
    $(function () {
        $(".navbar-brand").css("padding-top",0).css("padding-bottom",0);
        var CURRENT_URL = window.location.href;
        // console.log(CURRENT_URL);
        var contador = 1;
        if(CURRENT_URL.split("/")[3]=="")
            CURRENT_URL = CURRENT_URL.substring(0,CURRENT_URL.length-1);

        $(".navbar-right").find('a[href="' + CURRENT_URL + '"]').addClass("active");
    });
  </script>

</body>

</html>