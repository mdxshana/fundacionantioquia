<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('encabezado'); ?>
    <div class="page-banner" style="padding:40px 0; background: url(images/slide-02-bg.jpg) center #f9f9f9;">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h2>Nosotros</h2>

                </div>
                <div class="col-md-6">
                    <ul class="breadcrumbs">
                        <li><a href="#">Inicio</a></li>
                        <li>Nosotros</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-content">


            <div class="row">

                <div class="col-md-7">

                    <!-- Classic Heading -->
                    <h3 class="classic-title"><span>Quienes Somos</span></h3>

                    <!-- Some Text -->
                    <?php echo $somos->texto; ?>


                </div>

                <div class="col-md-5">

                    <!-- Start Touch Slider -->
                    <div class="touch-slider" data-slider-navigation="true" data-slider-pagination="true">
                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="item"><img alt="" src="images/<?php echo e($image->imagen); ?>"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                    <!-- End Touch Slider -->

                </div>

            </div>
            <div class="row" style="margin: 30px 0;">
                <img alt="" src="images/<?php echo e($imageSomos->imagen); ?>">
            </div>

            <!-- Divider -->
            <div class="hr1" style="margin-bottom:50px;"></div>

            <div class="row">

                <div class="col-md-6">

                    <!-- Classic Heading -->
                    <h3 class="classic-title"><span>Misión</span></h3>

                    <!-- Some Text -->
                    <?php echo $mision->texto; ?>


                </div>

                <div class="col-md-6">

                    <!-- Classic Heading -->
                    <h3 class="classic-title"><span>Visión</span></h3>

                    <!-- Some Text -->
                    <?php echo $vision->texto; ?>

                </div>

                <div class="col-md-12" style="margin-top: 30px;">
                    <div class="big-title text-center">
                        <h3 class="classic-title"> <span><strong>Modelo de atención "TEO-TERAPÉUTICO"</strong></span></h3>
                    </div>
                    <?php echo $modelo->texto; ?>

                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front-end.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>