<div id="left-menu">
    <div class="sub-left-menu scroll">
        <ul class="nav nav-list">
            <li><div class="left-bg"></div></li>
            <li class="time">
                <h1 class="animated fadeInLeft">21:00</h1>
                <p class="animated fadeInRight">Sat,October 1st 2029</p>
            </li>
            <li class="ripple">
                <a href="<?php echo e(route("editHome")); ?>"><span class="fa fa-pencil-square-o"></span>Editar Inicio</a>
            </li>
            <li class="ripple">
                <a href="<?php echo e(route("nuevoAdmin")); ?>"><span class="fa fa-user"></span>Adminstradores</a>
            </li>
            <li class="ripple">
                <a href="<?php echo e(route("editServicios")); ?>"><span class="fa fa-suitcase"></span>Servicios</a>
            </li>
            <li class="ripple">
                <a href="<?php echo e(route("nosotros")); ?>"><span class="fa fa-users"></span>Nosotros</a>
            </li>
            <li class="ripple">
                <a href="<?php echo e(route("editGalerias")); ?>"><span class="fa fa-picture-o"></span>Galeria</a>
            </li>
            <li class="ripple">
                <a href="<?php echo e(route("videos")); ?>"><span class="fa fa-video-camera"></span>Videos</a>
            </li>
            <li class="ripple">
                <a href="<?php echo e(route("editRequisitos")); ?>"><span class="fa fa-video-camera"></span>Requisitos</a>
            </li>

            
                
                    
                    
                
                
                    
                    
                
            
            
                
                    
                    
                
                
                    
                    
                    
                    
                
            
            
                    
                
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                
            
            
                
                    
                    
                    
                    
                
            
            
                
                    
                    
                    
                
            
            
            
                
                    
                    
                    
                
            
            
                
                    
                    
                    
                    
                    
                    
                    
                    
                
            
            
                
                    
                    
                    
                        
                            
                            
                        
                        
                            
                            
                            
                        
                    
                
            
            
        </ul>
    </div>
</div>