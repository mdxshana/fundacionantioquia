<nav class="navbar navbar-default header navbar-fixed-top">
    <div class="col-md-12 nav-wrapper">
        <div class="navbar-header" style="width:100%;">
            <div class="opener-left-menu is-open">
                <span class="top"></span>
                <span class="middle"></span>
                <span class="bottom"></span>
            </div>
            <a href="index.html" class="navbar-brand">
                <b>Fundacion Antioquía</b>
            </a>


            <ul class="nav navbar-nav navbar-right user-nav">
                <li class="user-name"><span><?php echo e(Auth::user()->nombre." ".Auth::user()->apellido); ?></span></li>
                <li class="dropdown avatar-dropdown">
                    <img src="/img/<?php echo e(Auth::user()->avatar); ?>" class="img-circle avatar" alt="user name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"/>
                    <ul class="dropdown-menu user-dropdown">
                        <li><a href="<?php echo e(route("perfil")); ?>"><span class="fa fa-user"></span> Mi perfil</a></li>
                        
                        <li role="separator" class="divider"></li>
                        <li class="more text-center">
                            <a href="<?php echo e(route("logout")); ?>"><span class="fa fa-sign-out fa-2x "></span></a>
                            
                                
                                
                                
                            
                        </li>
                    </ul>
                </li>
                
            </ul>
        </div>
    </div>
</nav>