<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="description" content="Miminium Admin Template v.1">
    <meta name="author" content="Isna Nur Azis">
    <meta name="keyword" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin - Fundación Antioquía</title>
    <meta name='csrf-param' content='authenticity_token'>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- start: Css -->
    <?php echo Html::style('back-end/css/bootstrap.min.css'); ?>

    

    <!-- plugins -->
    <?php echo Html::style('back-end/css/plugins/font-awesome.min.css'); ?>

    <?php echo Html::style('back-end/css/plugins/animate.min.css'); ?>

    <?php echo Html::style('back-end/css/style.css'); ?>


    <?php echo $__env->yieldContent('style'); ?>

    
    
    
    <!-- end: Css -->

    <link rel="shortcut icon" href="/img/logomi.png">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <?php echo Html::script('back-end/js/html5shiv.min.js'); ?>

    <?php echo Html::script('back-end/js/respond.min.js'); ?>

    <!--<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>-->
    
    <![endif]-->
</head>

<body id="mimin" class="dashboard">
<!-- start: Header -->
<?php echo $__env->make('layouts.back-end.menu-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- end: Header -->

<div class="container-fluid mimin-wrapper">

    <!-- start:Left Menu -->
    <?php echo $__env->make('layouts.back-end.menu-side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- end: Left Menu -->


    <!-- start: Content -->
    <div id="content">
        <?php echo $__env->yieldContent('cabecera'); ?>
        <div class="col-md-12">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <!-- end: content -->

</div>

<!-- start: Mobile -->
<?php echo $__env->make('layouts.back-end.menu-mobile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- end: Mobile -->


<!-- end: Content -->
<!-- start: Javascript -->
<?php echo Html::script('back-end/js/jquery.min.js'); ?>

<?php echo Html::script('back-end/js/jquery.ui.min.js'); ?>

<?php echo Html::script('back-end/js/bootstrap.min.js'); ?>






<!-- plugins -->
<?php echo Html::script('back-end/js/plugins/moment.min.js'); ?>

<?php echo Html::script('back-end/js/plugins/jquery.nicescroll.js'); ?>





<!-- custom -->
<?php echo Html::script('back-end/js/main.js'); ?>


<!-- end: Javascript -->

<!-- Modal Bootstrap-->
<div id='modalBs' class='modal fade'>
    <div class="modal-dialog">
        <div class="modal-content">
        </div>
    </div>
</div>


<?php echo Html::script('js/inicio.js'); ?>


<?php echo $__env->yieldContent('script'); ?>

<script>
    $(function () {
        var CURRENT_URL = window.location.href;
        // console.log(CURRENT_URL);
        var contador = 1;
        if(CURRENT_URL.split("/")[3]=="")
            CURRENT_URL = CURRENT_URL.substring(0,CURRENT_URL.length-1);

        $("#left-menu").find('a[href="' + CURRENT_URL + '"]').parents("li").addClass("active").children("a").addClass("active");
    });
</script>
</body>
</html>