<?php $__env->startSection('style'); ?>
    <title>Fundación Antioquía</title>
    <style>
        #content{
            padding: 0;
        }
        .service{
            height: 200px;
        }


        @media (max-width: 450px) {
            .carousel-inner>.item>img {
                height: 300px;!important;
            }
        }
        @media (min-width:451px) and (max-width: 800px){
            .carousel-inner>.item>img {
                height: 400px;!important;
            }
        }
        @media (min-width:801px) and (max-width: 991px){
            .carousel-inner>.item>img {
                height: 450px;!important;
            }
            .service{
                width: 100%;
            }
        }
        @media (min-width:992px) and (max-width: 1199px){
            .carousel-inner>.item>img {
                height: 500px;!important;
            }
            .service{
                width: 100%;
            }
        }
        @media (min-width: 1200px){
            .carousel-inner>.item>img {
                height: 600px;!important;
            }
            .service{
                width: 100%;
            }
        }
        p{
            font-size: 16px;
            color: #101010;
            line-height: 25px;
        }
        .big-title h1 strong{
            font-weight: 700;!important;
        }
        .member-photo{
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <section id="home">
        <!-- Carousel -->
        <div id="main-slide" class="carousel slide" data-ride="carousel">

            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php for($i=0; $i<count($galeria); $i++): ?>
                    <li data-target="#main-slide" data-slide-to="<?php echo e($i); ?>" <?php echo e(($i==0)?'class=active':''); ?>></li>
                <?php endfor; ?>
            </ol>
            <!--/ Indicators end-->

            <!-- Carousel inner -->
            <div class="carousel-inner">
                <?php $__currentLoopData = $galeria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $foto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="item <?php echo e(($clave==0)?'active':''); ?>">
                        <img class="fotoSlider" src="images/<?php echo e($foto); ?>" alt="slider" style="max-height: 600px; min-height: 200px">
                        
                            
                                
                                    
                                
                                
                                    
                                
                                
                                
                            
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <!-- Carousel inner end-->

            <!-- Controls -->
            <a class="left carousel-control" href="#main-slide" data-slide="prev">
                <span><i class="fa fa-angle-left"></i></span>
            </a>
            <a class="right carousel-control" href="#main-slide" data-slide="next">
                <span><i class="fa fa-angle-right"></i></span>
            </a>
        </div>
        <!-- /carousel -->
    </section>

    <div class=" section pricing-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- Start Big Heading -->
                    <div class="big-title text-center">
                        <h1 class="classic-title"> <span><strong>Filosofía</strong></span></h1>
                    </div>
                    <!-- End Big Heading -->

                    <!-- Text -->

                    <p class="text-justify">
                        <?php echo $texto; ?>

                    </p>

                    
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="big-title text-center">
                        <h1 class="classic-title"><span><strong>Servicios</strong></span></h1>
                    </div>
                </div>
            </div>

            <div class="row">
                <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clave => $servicio): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col-md-3 col-sm-6 col-xs-12 servicio" data-animation="fadeIn" data-animation-delay="03">
                        <div class="team-member modern">
                            <!-- Memebr Photo, Name & Position -->
                            <div class="member-photo text-center">
                                <img alt="" src="/images/<?php echo e($servicio); ?>" class="service"/>
                                <div class="member-name"><?php echo e($clave); ?><span></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo Html::script('front-end/js/owl.carousel.min.js'); ?>

    <script>
        $(function(){
            $(".member-photo").click(function(){
                window.open('/servicios', '_blank');
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front-end.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>